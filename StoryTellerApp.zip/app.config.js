import 'dotenv/config';
import { GOOGLE_API_KEY } from './utils/config';

export default {
  expo: {
    name: "StoryTellerApp",
    slug: "storyteller-app",
    platforms: ["ios", "android"],
    plugins: [
    ["expo-audio", { 
       microphonePermission: "Allow StoryTellerApp to access your microphone for recording ideas."
     }]
    ],
    android: {
      package: "com.ai4magic.storytellerapp"
    },
    version: "1.0.0",
    sdkVersion: "54.0.0",
    splash: {
      "image": "./assets/splash/splashscreen.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    extra: {
      eas:
      {
      projectId: "9374ea54-855c-4329-a286-fcb1c5d5da47"
      },
      OPENAI_API_KEY: process.env.OPENAI_API_KEY,
      ELEVENLABS_API_KEY: process.env.ELEVENLABS_API_KEY,
      GOOGLE_API_KEY: process.env.GOOGLE_API_KEY,
      GOOGLE_TTS_API_KEY: process.env.GOOGLE_TTS_API_KEY,
    },
  },
};