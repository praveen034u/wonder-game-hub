import Constants from 'expo-constants';

export const OPENAI_API_KEY = Constants.expoConfig.extra.OPENAI_API_KEY;
export const ELEVENLABS_API_KEY = Constants.expoConfig.extra.ELEVENLABS_API_KEY;
export const GOOGLE_API_KEY = Constants.expoConfig.extra.GOOGLE_API_KEY;
export const GOOGLE_TTS_API_KEY = Constants.expoConfig.extra.GOOGLE_TTS_API_KEY;