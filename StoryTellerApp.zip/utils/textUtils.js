export const sanitizeStoryResponseText = (rawText) => {
  try {
    let cleaned = rawText;

    // If the response is wrapped in ```json ... ```
    if (cleaned.includes('```json')) {
      cleaned = cleaned.replace(/^```json[\s\r\n]*/i, '').replace(/```\s*$/, '');
    }

    // If response contains escaped JSON (i.e. double-stringified)
    // Try parsing once to see if it gives us a JSON string
    try {
      const maybeStringified = JSON.parse(cleaned);
      if (typeof maybeStringified === 'string') {
        cleaned = maybeStringified;
      } else if (Array.isArray(maybeStringified)) {
        cleaned = maybeStringified;
      }
    } catch (e) {
      // continue with original `cleaned` if first parse fails
    }

    // Final parse attempt
    const parsed = typeof cleaned === 'string' ? JSON.parse(cleaned) : cleaned;

    if (!Array.isArray(parsed)) {
      console.error('Parsed response is not an array:', parsed);
      return [];
    }

    const validSegments = parsed
      .map((seg, i) => ({
        id: seg.id || `segment_${i + 1}`,
        text: seg.text?.trim(),
        image_prompt: seg.image_prompt?.trim(),
        audio_prompt: seg.audio_prompt?.trim()
      }))
      .filter(seg => seg.text && seg.image_prompt && seg.audio_prompt);

    // console.log("Validated story segments:", validSegments);
    return validSegments;
  } catch (error) {
    console.error("Failed to sanitize and parse Gemini response:", error);
    return [];
  }
};


export const buildStorySegments = (storyText) => {
  const segments = sanitizeStoryResponseText(storyText);

  if (!Array.isArray(segments) || segments.length === 0) {
    console.warn("No valid story segments returned after sanitization.");
    return [];
  }

  return segments.map((segment, index) => ({
    id: segment.id || `segment_${index + 1}`,
    text: segment.text?.trim() || '',
    image_prompt: segment.image_prompt?.trim() || '',
    audio_prompt: segment.audio_prompt?.trim() || '',
  }));
};
