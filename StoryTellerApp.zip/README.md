List of command to run appilication

1- npm install -g expo-cli 
2- npx expo start
3- npx expo start --clear

nvm install 20.19.4
nvm use 20.19.4
node -v

npx expo install react react-dom react-native react-native-web

npx expo install expo-file-system

npx expo install expo-file-system @expo/metro-runtime expo-constants react-native-gesture-handler react-native-safe-area-context react-native-screens