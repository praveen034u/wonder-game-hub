import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text } from 'react-native';

import StoryCrafter from './components/StoryCrafter';
import StorySyncPlayer from './components/StorySyncPlayer';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="StoryCrafter">
        <Stack.Screen
          name="StoryCrafter"
          component={StoryCrafter}
          options={{ title: 'Create Your Story' }}
        />
        <Stack.Screen
          name="StorySyncPlayer"
          component={StorySyncPlayer}
          options={{ title: 'Your Animated Story' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
