import React, { useState } from 'react';
import {View, Text, TextInput, ActivityIndicator, Alert, Image, TouchableOpacity, ScrollView, StyleSheet} from 'react-native';
import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';
import axios from 'axios';
import { fromByteArray } from 'base64-js';
import { OPENAI_API_KEY, GOOGLE_API_KEY } from '../utils/config';
import { buildStorySegments } from '../utils/textUtils';

const StoryCrafter = ({ navigation }) => {
  const [recording, setRecording] = useState(null);
  const [recognizedText, setRecognizedText] = useState('');
  const [loading, setLoading] = useState(false);

  const startRecording = async () => {
    const { granted } = await Audio.requestPermissionsAsync();
    if (!granted) return Alert.alert("Permission needed", "Microphone permission is required.");
    await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
    const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
    setRecording(recording);
  };

  const stopRecording = async () => {
    setLoading(true);
    try {
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      const formData = new FormData();
      formData.append("file", { uri, name: "recording.mp3", type: "audio/mpeg" });
      formData.append("model", "whisper-1");

      const response = await axios.post("https://api.openai.com/v1/audio/transcriptions", formData, {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "multipart/form-data",
        }
      });

      setRecognizedText(response.data.text);
    } catch (err) {
      Alert.alert("Transcription failed", err.message || "Something went wrong.");
    } finally {
      setRecording(null);
      setLoading(false);
    }
  };

  const generateStorySegments = async () => {
    if (!recognizedText) return Alert.alert("Input Needed", "Please speak or type a story idea first.");
    setLoading(true);
    try {
      const prompt = `You are an imaginative children's story generator. Based on this idea: "${recognizedText}", create a story in 5 short segments.
For each segment, return:
- "text": narration
- "image_prompt": visual scene
- "audio_prompt": narration again (no symbols)
Respond ONLY in JSON array format.`;

      const geminiResponse = await axios.post(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
        { contents: [{ parts: [{ text: prompt }] }] },
        { headers: { 'x-goog-api-key': GOOGLE_API_KEY, 'Content-Type': 'application/json'} }
      );

      const storyText = geminiResponse.data.candidates[0].content.parts[0].text;
      // console.log("Gemini raw response:", geminiResponse.data.candidates[0].content.parts[0].text);
      const segments=buildStorySegments(storyText);
     
      navigation.navigate('StorySyncPlayer', { storySegments: segments });
    } catch (error) {
      Alert.alert("Story Error", error.message || "Failed to generate story.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/splash/splashscreen.png')} style={styles.logo} />
      <Text style={styles.headerText}>Tell me your story!</Text>

      <TouchableOpacity style={styles.micButton} onPress={recording ? stopRecording : startRecording}>
        <Text style={styles.micButtonText}>{recording ? "🛑 Stop Recording" : "🎙️ Start Recording"}</Text>
      </TouchableOpacity>

      <ScrollView style={styles.textBoxContainer}>
        <TextInput
          placeholder="You can also edit or type here..."
          value={recognizedText}
          onChangeText={setRecognizedText}
          multiline
          scrollEnabled
          style={styles.textInput}
          textAlignVertical="top"
        />
      </ScrollView>

      {loading
        ? <ActivityIndicator size="large" color="#FF6F61" />
        : <TouchableOpacity style={styles.generateButton} onPress={generateStorySegments}>
            <Text style={styles.generateButtonText}>✨ Generate Story ✨</Text>
          </TouchableOpacity>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#FFF7E6' },
  logo: { width: 120, height: 120, alignSelf: 'center', marginBottom: 10 },
  headerText: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 10, color: '#FF6F61' },
  micButton: { backgroundColor: '#FFB74D', padding: 12, borderRadius: 20, alignItems: 'center', marginBottom: 15 },
  micButtonText: { fontSize: 18, color: '#fff' },
  textBoxContainer: { flex: 1, marginBottom: 10 },
  textInput: {
    borderWidth: 2,
    borderColor: '#FFCC80',
    borderRadius: 15,
    padding: 15,
    fontSize: 16,
    minHeight: 290,
    maxHeight: 290,
    backgroundColor: '#FFFFFF'
  },
  generateButton: {
    backgroundColor: '#81D4FA',
    padding: 14,
    borderRadius: 20,
    alignItems: 'center',
    marginBottom: 160 
  },
  generateButtonText: { fontSize: 18, color: '#004D40', fontWeight: 'bold' }
});

export default StoryCrafter;
