// =============================
// File: StorySyncPlayer.js  (Expo SDK 54, Expo Go compatible)
// Uses expo-audio hooks; fixed placeholder asset path
// =============================

import React, { useEffect, useState } from 'react';
import { GOOGLE_TTS_API_KEY, ELEVENLABS_API_KEY } from '../utils/config';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import axios from 'axios';
import * as FileSystem from 'expo-file-system/legacy';
import {
  GestureHandlerRootView,
  FlingGestureHandler,
  Directions,
  State,
} from 'react-native-gesture-handler';

const EPSILON = 0.25;

export default function StorySyncPlayer({ route }) {
  const { storySegments } = route.params;
  const [assets, setAssets] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const player = useAudioPlayer(null, { downloadFirst: true });
  const status = useAudioPlayerStatus(player);

  useEffect(() => {
    const isValid = storySegments?.every(
      (s) => typeof s.text === 'string' && typeof s.image_prompt === 'string' && typeof s.audio_prompt === 'string'
    );
    if (!isValid) {
      Alert.alert('Invalid story format', 'Some segments are missing required fields.');
      setIsLoading(false);
      return;
    }
    generateAssets();
  }, []);

  useEffect(() => {
    const run = async () => {
      if (!assets.length || currentIndex >= assets.length) return;
      const src = assets[currentIndex]?.audio;
      if (!src) return;
      try {
        player.replace({ uri: src });
        player.play();
      } catch (e) {
        console.warn('Audio replace/play failed:', e?.message || String(e));
      }
    };
    run();
  }, [assets, currentIndex]);

  useEffect(() => {
    if (!status) return;
    const { isLoaded, playing, currentTime, duration } = status;
    if (!isLoaded) return;
    if (duration > 0 && !playing && currentTime >= duration - EPSILON) {
      if (currentIndex + 1 < assets.length) setCurrentIndex((i) => i + 1);
    }
  }, [status, currentIndex, assets.length]);

  const generateAssets = async () => {
    setIsLoading(true);
    const results = [];
    for (const segment of storySegments) {
      try {
        const imageUrl = await generateImageFromGemini(segment.image_prompt);
        const audioUri = await generateAudioFromGoogleTTS(segment.audio_prompt);
        results.push({ ...segment, image: imageUrl ?? null, audio: audioUri ?? null });
      } catch (error) {
        console.error('Error processing segment:', error);
        Alert.alert('Error', 'Failed to load story content.');
      }
    }
    setAssets(results.filter(Boolean));
    setCurrentIndex(0);
    setIsLoading(false);
  };

  const generateImageFromGemini = async (prompt) => {
    try {
      const response = await axios.post(
        'https://image-genai-api-41368094823.us-central1.run.app/generate-image?prompt=' + encodeURIComponent(prompt),
        {}
      );
      if (response.status === 200 && response.data.url) return response.data.url;
      throw new Error('Image generation failed');
    } catch (error) {
      console.error('Image generation error:', error);
      return null;
    }
  };

  const arrayBufferToBase64 = (buffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return global.btoa ? btoa(binary) : Buffer.from(binary, 'binary').toString('base64');
  };

  const generateAudioFromGoogleTTS = async (text) => {
    try {
      const response = await axios.post(
        'https://texttospeech.googleapis.com/v1/text:synthesize?key=' + GOOGLE_TTS_API_KEY,
        {
          input: { text },
          voice: { languageCode: 'en-US', name: 'en-US-Wavenet-D', ssmlGender: 'MALE' },
          audioConfig: { audioEncoding: 'MP3' },
        },
        { headers: { 'Content-Type': 'application/json' } }
      );
      const base64Audio = response.data?.audioContent;
      if (!base64Audio) throw new Error('TTS returned empty audioContent');
      const fileUri = `${FileSystem.cacheDirectory}${Date.now()}.mp3`;
      await FileSystem.writeAsStringAsync(fileUri, base64Audio, { encoding: 'base64' });
      return fileUri;
    } catch (error) {
      console.error('Google TTS audio generation error:', error?.message || error);
      throw error;
    }
  };

  const generateAudioFromElevenLabs = async (text) => {
    try {
      const response = await axios.post(
        'https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM',
        {
          text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: { stability: 0.5, similarity_boost: 0.7 },
        },
        {
          headers: {
            'xi-api-key': ELEVENLABS_API_KEY,
            'Content-Type': 'application/json',
            'User-Agent': 'StoryTellerApp/1.0',
          },
          responseType: 'arraybuffer',
        }
      );
      const bytes = new Uint8Array(response.data);
      let binary = ''; for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
      const base64Audio = global.btoa ? btoa(binary) : Buffer.from(binary, 'binary').toString('base64');
      const fileUri = `${FileSystem.cacheDirectory}${Date.now()}.mp3`;
      await FileSystem.writeAsStringAsync(fileUri, base64Audio, { encoding: 'base64' });
      return fileUri;
    } catch (error) {
      console.error('ElevenLabs audio generation error:', error?.message || error);
      throw error;
    }
  };

  const renderProgressBar = () => (
    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginVertical: 16, gap: 8 }}>
      {assets?.map((_, idx) => (
        <View key={idx} style={{ width: 30, height: 6, borderRadius: 3, backgroundColor: idx <= currentIndex ? '#007AFF' : '#D3D3D3' }} />
      ))}
    </View>
  );

  if (isLoading) return <ActivityIndicator size="large" color="#007AFF" style={{ marginTop: 50 }} />;
  if (!assets || assets.length === 0) {
    return <Text style={{ margin: 24, textAlign: 'center' }}>No playable segments were generated. Try again with a different prompt.</Text>;
  }

  const current = assets[currentIndex];

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <FlingGestureHandler
        direction={Directions.LEFT}
        onHandlerStateChange={({ nativeEvent }) => {
          if (nativeEvent.state === State.END && currentIndex < assets.length - 1) setCurrentIndex((i) => i + 1);
        }}
      >
        <FlingGestureHandler
          direction={Directions.RIGHT}
          onHandlerStateChange={({ nativeEvent }) => {
            if (nativeEvent.state === State.END && currentIndex > 0) setCurrentIndex((i) => i - 1);
          }}
        >
          <View style={{ flex: 1, padding: 20, alignItems: 'center', justifyContent: 'center' }}>
            {/* Use a known-good asset that exists in your repo (StoryCrafter uses this) */}
            <Image
              source={current?.image ? { uri: current.image } : require('../assets/splash/splashscreen.png')}
              style={{ width: 300, height: 300, borderRadius: 10, marginBottom: 20 }}
              resizeMode="cover"
            />

            <Text style={{ fontSize: 20, textAlign: 'center', marginBottom: 20, fontWeight: 'bold', color: '#6A1B9A' }}>
              {current?.text ?? ''}
            </Text>

            {renderProgressBar()}

            <TouchableOpacity
              onPress={() => {
                try {
                  if (status?.playing) player.pause();
                  else player.play();
                } catch (e) {
                  console.warn('Play/pause failed:', e?.message || String(e));
                }
              }}
              style={{ backgroundColor: '#FF6F61', padding: 14, borderRadius: 30, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3 }}
            >
              <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold' }}>
                {status?.playing ? '⏸️ Pause' : '▶️ Play Segment'}
              </Text>
            </TouchableOpacity>
          </View>
        </FlingGestureHandler>
      </FlingGestureHandler>
    </GestureHandlerRootView>
  );
}
